import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * @description: 客户端类
 * @author Eternity
 * @date 2023/10/24 16:12
 * @version 1.0
 */

//测试网址：www.5imx.com     本地地址：127.0.0.1
public class Client {

    /**
     * Input is taken from the keyboard
     */
    static BufferedReader keyboard = new BufferedReader(new InputStreamReader(
            System.in));
    /**
     * Output is written to the screen (standard out)
     */
    static PrintWriter screen = new PrintWriter(System.out, true);
    /**
     * default HTTP port is port 80
     */
    // 测试GET时，端口号修改为80，本地时端口号为2023（80端口被占用）
    private static int port = 2023;
    /**
     * Allow a maximum buffer size of 8192 bytes
     */
    private static int buffer_size = 8192;
    /**
     * The end of line character sequence.
     */
    private static String CRLF = "\r\n";

    public static void main(String[] args) throws Exception {
        try {
            /**
             * Create a new HttpClient object.
             */
            HttpClient myClient = new HttpClient();

            /**
             * Parse the input arguments.
             */
            if (args.length != 1) {
                System.err.println("Usage: Client <server>");
                System.exit(0);
            }

            /**
             * Connect to the input server
             */
            myClient.connect(args[0]);

            /**
             * Read the get request from the terminal.
             */
            screen.println(args[0] + " is listening to your request:");
            String request = keyboard.readLine();

            if (request.startsWith("GET")) {
                /**
                 * Ask the client to process the GET request.
                 */
                //测试的是网址的时候，用上一行（HTTP1.1），本地用下一行（HTTP/1.0）
                //myClient.processGetRequest(request + "\r\nConnection: close" + "\r\nHost: " + args[0]);
                myClient.processGetRequest(request);


            } else if (request.startsWith("PUT")) {
                /**
                 * Ask the client to process the PUT request.
                 */
                myClient.processPutRequest(request);
            } else {
                /**
                 * Do not process other request.
                 */
                screen.println("Bad request! \n");
                myClient.close();
                return;
            }

            /**
             * Get the headers and display them.
             */
            screen.println("Header: \n");
            screen.print(myClient.getHeader() + "\n");
            screen.flush();

            if (request.startsWith("GET")) {
                /**
                 * Ask the user to input a name to save the GET resultant web page.
                 */
                screen.println();
                screen.print("Enter the name of the file to save: ");
                screen.flush();
                String filename = keyboard.readLine();
                FileOutputStream outfile = new FileOutputStream(filename);

                /**
                 * Save the response to the specified file.
                 */
                String response = myClient.getResponse();
                outfile.write(response.getBytes("iso-8859-1"));
                outfile.flush();
                outfile.close();
            }

            /**
             * Close the connection client.
             */
            myClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
