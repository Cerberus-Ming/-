package server;

import rface.MeetingInterface;
import rface.MeetingService;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

/**
 * @description: RMI服务器端，用于启动RMI注册服务和绑定Meetingservice接口的实现类
 * @author: EternalCoder
 * @date: 2023/11/17 15:28
 * @version: 1.1
 */
public class RMIServer {

    /**
     * 启动RMI注册服务和绑定Meetingservice接口的实现类
     */
    public static void main(String[] args) {
        try {
            // 创建RMI注册表，指定端口号为1099
            LocateRegistry.createRegistry(1099);

            // 创建Meetingservice接口的实现类对象
            MeetingService meetingService = new MeetingService();

            // 将Meetingservice接口的实现类绑定到命名服务中，命名为"RMIMeetingService"
            Naming.rebind("RMIMeetingService", meetingService);

            // 打印服务器启动成功消息
            System.out.println("RMI Meeting Service Server started successfully");
        } catch (Exception e) {
            // 打印服务器启动失败消息及异常信息
            System.out.println("RMI Meeting Service Server failed to start");
            e.printStackTrace();
        }
    }
}
