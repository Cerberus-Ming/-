## 分布式实验四 程序说明

### 程序说明

本次实验包含两个独立的项目：Server和Client

Server实现了Web服务器类、用户类以及代办事件类，负责管理各种待办事项列表对象

Client类实现了客户端类，可以连接到一个服务器管理各种待办事项列表对象，Client可运行多个实例

### 运行说明

先运行Server中的WebServer，再运行Client中的Client（都没有程序参数，直接运行即可）

程序运行后，先注册用户，然后可以根据菜单给出命令，命令格式如下：

（时间格式： yyyy-MM-dd,hh:mm）
add <start time> <end time> <title>
query <start time> <end time>
delete <todo-list ID>
clear
help
quit

### 测试用例及运行截图

（用户注册略）

add 2023-10-30,03:00 2023-10-31,23:00 test1

add 2023-04-05,12:31 2023-04-06,15:32 test2

query 2023-01-01,00:01 2023-12-31,23:59

delete 1

clear

query 2023-01-01,00:01 2023-12-31,23:59

help

quits

![image-20231203211207199](C:\Users\钐二铭\AppData\Roaming\Typora\typora-user-images\image-20231203211207199.png)