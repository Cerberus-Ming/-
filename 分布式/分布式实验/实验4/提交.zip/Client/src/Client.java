import com.service.TodoList;
import com.service.User;
import com.service.WebServerService;
import com.service.WebService;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * Client 客户端类
 *
 * @description: 用于与 Web 服务进行交互的客户端程序，支持用户注册、添加待办事项、查询待办事项、删除待办事项、清空待办事项列表等功能。
 * @author Eternity
 * @date 2023/12/2 10:46
 * @version 1.0
 */
public class Client {
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd,hh:mm");
    private static final User user = new User();
    private static WebService service;

    /**
     * 处理客户端命令
     *
     * @param cmd 客户端输入的命令
     * @return 返回结果，返回1则终止程序，返回0则继续执行
     */
    public static int handle(String cmd) {
        String[] cmdSplit = cmd.split(" ");
        switch (cmdSplit[0]) {
            case "add": {
                add(cmd);
                return 0;
            }
            case "query": {
                query(cmd);
                return 0;
            }
            case "delete": {
                delete(cmd);
                return 0;
            }
            case "clear": {
                service.clear(user.getUsername());
                System.out.println("All the todo-lists have cleared");
                return 0;
            }
            case "help": {
                menu();
                return 0;
            }
            case "quit": {
                return 1;
            }
            default: {
                System.err.println("Wrong command");
                return 0;
            }
        }
    }

    /**
     * 用户注册操作
     */
    private static void register() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Registration: please enter the username");
            String username = in.nextLine();
            System.out.println("Registration: please enter the password");
            String password = in.nextLine();
            user.setUsername(username);
            user.setPassword(password);
            if (service.register(user)) {
                System.out.println("Registration success");
                break;
            } else {
                System.err.println("Registration failed: The user name already exists");
            }
        }
    }

    /**
     * add操作
     *
     * @param cmd 输入的命令
     */
    public static void add(String cmd) {
        String[] command = cmd.split(" ");
        if (command.length < 4) {
            System.err.println("Wrong command. A correct one should be: add [start time] [end time] [title]");
        } else {
            try {
                Date start = dateFormat.parse(command[1]);
                Date end = dateFormat.parse(command[2]);

                if (start.before(end)) { // 判断时间顺序是否正确
                    TodoList item = new TodoList();
                    item.setUsername(user.getUsername());
                    item.setStartTime(dateFormatConversion(start));
                    item.setEndTime(dateFormatConversion(end));
                    String title = "";
                    for (int i = 3; i < command.length - 1; i++) {
                        title = title + command[i] + " ";
                    }
                    title = title + command[command.length - 1];
                    item.setTitle(title);
                    TodoList result = service.add(user.getUsername(), item);
                    if (result != null) {
                        System.out.println("Todo-list added successfully. ID: " + result.getID());
                    } else {
                        System.err.println("Failed to add todo-list: time conflict");
                    }
                } else {
                    System.err.println("Invalid time");
                }
            } catch (ParseException e) {
                System.err.println("Wrong date format. A correct one should be: [yyyy-MM-dd,hh:mm]");
            }
        }
    }

    /**
     * query操作
     *
     * @param cmd 输入的命令
     */
    public static void query(String cmd) {
        String[] command = cmd.split(" ");
        if (command.length != 3) {
            System.err.println("Wrong command. A correct one should be: query [start time] [end time]");
        } else {
            try {
                Date start = dateFormat.parse(command[1]);
                Date end = dateFormat.parse(command[2]);
                if (!start.before(end)) { //判断时间顺序是否正确
                    System.err.println("Invalid time");
                    return;
                }
                List<TodoList> queryList;
                queryList = service.query(user.getUsername(), dateFormatConversion(start), dateFormatConversion(end)); //符合条件的待办事项列表
                if (queryList.isEmpty()) {
                    System.out.println("No todo-lists meeting the conditions");
                } else {
                    for (TodoList todoList : queryList) {
                        String info = "[ id: " + todoList.getID() + ", title: " + todoList.getTitle() + " ]\n" + "[ start time: " + todoList.getStartTime().toString() + " ]\n" +
                                "[ end time: " + todoList.getEndTime().toString() + " ]\n";
                        System.out.println(info);
                    }
                }
            } catch (ParseException e) {
                System.err.println("Wrong date format. A correct one should be: [yyyy-MM-dd,hh:mm]");
            }
        }
    }

/**
 * 将Date日期用XMLGregorianCalendar形式表示
 *
 * @param date Date日期
 * @return XMLGregorianCalendar形式的日期
 */
public static XMLGregorianCalendar dateFormatConversion(Date date) {
    XMLGregorianCalendar result;
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    try {
        DatatypeFactory factory = DatatypeFactory.newInstance();
        result = factory.newXMLGregorianCalendar();

        result.setYear(calendar.get(Calendar.YEAR));
        result.setMonth(calendar.get(Calendar.MONTH) + 1);
        result.setDay(calendar.get(Calendar.DAY_OF_MONTH));
        result.setHour(calendar.get(Calendar.HOUR_OF_DAY));
        result.setMinute(calendar.get(Calendar.MINUTE));
        result.setSecond(calendar.get(Calendar.SECOND));
        return result;
    } catch (DatatypeConfigurationException e) {
        e.printStackTrace();
    }
    return null;
}

    /**
     * delete操作
     *
     * @param cmd 输入的命令
     */
    public static void delete(String cmd) {
        String[] command = cmd.split(" ");
        if (command.length != 2) {
            System.err.println("Wrong command. A correct one should be: delete [todo-list ID]");
        } else {
            int id = Integer.parseInt(command[1]);
            if (service.delete(user.getUsername(), id)) {
                System.out.println("Deletion succeeded");
            } else {
                System.err.println("Delete failed");
            }
        }
    }

    /**
     * 打印菜单
     */
    public static void menu() {
        System.out.println("\tWeb Service MENU:");
        System.out.println("\t1. add:");
        System.out.println("\t\targuments: <start time> <end time> <title> Time format: [yyyy-MM-dd,hh:mm]");
        System.out.println("\t2. query:");
        System.out.println("\t\targuments: <start time> <end time> Time format: [yyyy-MM-dd,hh:mm]");
        System.out.println("\t3. delete:");
        System.out.println("\t\targuments: <todo-list ID>");
        System.out.println("\t4. clear:");
        System.out.println("\t\tno arguments");
        System.out.println("\t5. help:");
        System.out.println("\t\tno arguments");
        System.out.println("\t6. quit:");
        System.out.println("\t\tno arguments");
    }

    public static void main(String[] args) {
        WebServerService webService = new WebServerService();
        service = webService.getPort();
        System.out.println("Connection succeeded");

        register();
        menu();

        int flag;
        Scanner in = new Scanner(System.in);
        do {
            String command = in.nextLine();
            flag = handle(command);
        } while (flag != 1);
        in.close();
    }
}
