import java.util.Date;

/**
 * TodoList 待办事项类
 *
 * @description: 表示用户的待办事项，包括起始时间、结束时间、标题等属性
 * @author Eternity
 * @date 2023/12/2 11:03
 * @version 1.0
 */
public class TodoList {

    private int id;
    private String username;// 创建项目的用户名
    private Date startTime;// 起始时间
    private Date endTime;// 结束时间
    private String title;// 标题

    /**
     * 无参构造函数
     */
    public TodoList() {}

    /**
     * 有参构造函数
     *
     * @param id ID
     * @param username 用户名
     * @param startTime 起始时间
     * @param endTime 结束时间
     * @param title 标题
     */
    public TodoList(int id, String username, Date startTime, Date endTime, String title) {
        super();
        this.id = id;
        this.username = username;
        this.startTime = startTime;
        this.endTime = endTime;
        this.title = title;
    }

    /**
     * 获取创建事项的用户名
     *
     * @return 用户名
     */
    public String getUsername() {
        return username;
    }

    /**
     * 设置创建者用户名
     *
     * @param username 用户名
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 获取事项ID
     *
     * @return 项目ID
     */
    public int getID() {
        return id;
    }

    /**
     * 设置事项ID
     *
     * @param todoListID 项目ID
     */
    public void setID(int todoListID) {
        this.id = todoListID;
    }

    /**
     * 获取起始时间
     *
     * @return 起始时间
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * 设置起始时间
     *
     * @param date 起始时间
     */
    public void setStartTime(Date date) {
        this.startTime = date;
    }

    /**
     * 获取结束时间
     *
     * @return 结束时间
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * 设置结束时间
     *
     * @param date 结束时间
     */
    public void setEndTime(Date date) {
        this.endTime = date;
    }

    /**
     * 获取标题
     *
     * @return 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 重写 toString 方法，返回对象的字符串表示
     *
     * @return 字符串表示
     */
    @Override
    public String toString() {
        return "[ID: " + id + ", startTime: " + startTime + ", endTime: " + endTime + ", title: "
                + title + "]";
    }
}
