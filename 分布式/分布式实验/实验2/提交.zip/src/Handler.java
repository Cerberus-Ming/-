import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.regex.Matcher;


/**
 * @description: 线程负责处理客户端的连接
 * @author Eternity
 * @date 2023/11/2 16:25
 * @version 1.0
 */
public class Handler implements Runnable {
    final String CRLF = "\r\n";
    private final Socket socket;
    private final String rootPath;
    StringBuilder request;
    StringBuilder response;
    StringBuilder html;
    BufferedReader bufferedReader = null;
    BufferedInputStream inputStream = null;
    BufferedOutputStream outputStream = null;
    String line = "";
    String[] header;
    byte[] buffer;


    /**
     * 构造函数
     *
     * @param socket 与该客户端连接的socket
     * @param path   服务器根目录
     */
    public Handler(Socket socket, String path) {

        this.request = new StringBuilder();
        this.response = new StringBuilder();
        this.html = new StringBuilder();
        this.socket = socket;
        this.rootPath = path;
    }


    @Override
    public void run() {
        try {
            inputStream = new BufferedInputStream(socket.getInputStream());
            outputStream = new BufferedOutputStream(socket.getOutputStream());
            processRequest();
            header = line.split(" ");
            // 分割请求头 按照请求的参数分别调用不同的方法处理
            if (header.length == 3) {
                if (header[2].equals("HTTP/1.0") || header[2].equals("HTTP/1.1")) {
                    if (header[0].equals("GET")) {
                        processGET();
                    } else if (header[0].equals("PUT")) {
                        processPUT();
                    } else {
                        response400();
                    }
                } else {
                    response400();
                }
            } else {
                response400();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 分割请求头和请求体
     */
    private void processRequest() {
        try {
            int last = 0;
            int c;
            boolean inHeader = true;
            boolean flag = false;
            String mark = "";
            while (inHeader && (c = inputStream.read()) != -1) {
                switch (c) {
                    case '\r':
                        break;
                    case '\n':
                        if (c == last) {
                            inHeader = false;
                            break;
                        }
                        last = c;
                        request.append(mark + "\n");
                        if (!flag) {
                            line = mark;
                        }
                        mark = "";
                        flag = true;
                        break;
                    default:
                        last = c;
                        mark += (char) c;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 处理客户端Get请求
     */
    private void processGET() {

        //分html和jpg的情况
        if (header[1].endsWith(".html") || header[1].endsWith(".htm")) {
            File file = new File(rootPath + "\\" + header[1]);
            if (file.exists()) {
                sendHTML(file);
            } else {
                response404();
            }
        } else if (header[1].endsWith(".jpg")) {
            File file = new File(rootPath + "\\" + header[1]);
            if (file.exists()) {
                sendIMG(file);
            } else {
                response404();
            }
        }
    }

    /**
     * 处理客户端Put请求
     */
    private void processPUT() {

        try {
            String fileInfo = line.split(" ")[1]; // 提取目录 + 文件名
            String fileName = fileInfo.split("/")[fileInfo.split("/").length - 1]; // 提取文件名
            String dir, saveDir, savePath;

            //判断文件是否包含目录信息，若包含不存在的目录，则创建
            if (!fileName.equals(fileInfo)) {
                dir = fileInfo.substring(0, fileInfo.length() - fileName.length() - 1);
                saveDir = rootPath + "\\" + dir.replaceAll("/", Matcher.quoteReplacement(File.separator));
                File fileDir = new File(saveDir);
                if ((!fileDir.exists()) && (!fileDir.isDirectory())) {
                    fileDir.mkdirs();
                }
            }
            savePath = rootPath + "\\" + fileInfo.replaceAll("/", Matcher.quoteReplacement(File.separator));
            File file = new File(savePath);
            String responseHeader;
            //判断文件是否存在 根据不同情况使Header的内容对应
            if (!file.exists()) {
                responseHeader = "HTTP/1.0 201 Created" + CRLF;
                file.createNewFile();
            } else {
                responseHeader = "HTTP/1.0 200 OK" + CRLF;
            }

            // 写入文件
            buffer = new byte[4096];
            FileOutputStream fos = new FileOutputStream(savePath);
            int data;
            while ((data = inputStream.read()) != -1) {
                fos.write(data);
                fos.flush();
            }
            fos.flush();

            // 填写响应头信息
            responseHeader += "Server: LocalHttpServer/1.0 " + CRLF;
            if (fileName.toLowerCase().endsWith("jpg") || fileName.toLowerCase().endsWith("jpeg")) {
                responseHeader += "Content-type: " + "jpeg" + CRLF;
            } else if (fileName.toLowerCase().endsWith("html") ||
                    fileName.toLowerCase().endsWith("htm") || fileName.toLowerCase().endsWith("txt")) {
                responseHeader += "Content-type: " + "text/html" + CRLF;
            } else {
                responseHeader += "Content-type: " + "unknown" + CRLF;
            }
            responseHeader += "Content-length: " + file.length() + CRLF + CRLF;

            // 发送响应头
            buffer = responseHeader.getBytes();
            outputStream.write(buffer, 0, responseHeader.length());
            outputStream.flush();

            fos.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 返回400 Bad Request
     */
    private void response400() {
        try {
            File dir = new File(rootPath + "\\response");
            if (!(dir.exists()) && (!dir.isDirectory())) {
                dir.mkdirs();
            }
            File file = new File(rootPath + "\\response\\400.html");
            if (!file.exists()) {
                file.createNewFile();
            }
            bufferedReader = new BufferedReader(new FileReader(file.getPath()));
            String str = bufferedReader.readLine();
            while (str != null) {
                html.append(str).append("\n");
                str = bufferedReader.readLine();
            }
            response.append("HTTP/1.0 400 Bad Request" + CRLF);
            response.append("Date: ").append(new Date()).append(CRLF);
            response.append("Content-Type: text/html;charset=ISO-8859-1" + CRLF);
            response.append("Content-Length: ").append(file.length() + 106).append(CRLF);
            response.append(CRLF);
            response.append(html);

            String message = response.toString();
            buffer = message.getBytes();
            outputStream.write(buffer, 0, message.length());
            outputStream.flush();
            outputStream.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 返回404 Not Found。
     */
    private void response404() {
        try {
            File dir = new File(rootPath + "\\response");
            if (!(dir.exists()) && (!dir.isDirectory())) {
                dir.mkdirs();
            }
            File file = new File(rootPath + "\\response\\404.html");
            if (!file.exists()) {
                file.createNewFile();
            }
            bufferedReader = new BufferedReader(new FileReader(file.getPath()));
            String str = bufferedReader.readLine();
            while (str != null) {
                html.append(str).append("\n");
                str = bufferedReader.readLine();
            }
            response.append("HTTP/1.0 404 Not Found" + CRLF);
            response.append("Date: ").append(new Date()).append(CRLF);
            response.append("Content-Type: text/html;charset=ISO-8859-1" + CRLF);
            response.append("Content-Length: ").append(file.length() + 106).append(CRLF);
            response.append(CRLF);
            response.append(html);
            String message = response.toString();
            buffer = message.getBytes();
            outputStream.write(buffer, 0, message.length());
            outputStream.flush();
            outputStream.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * 向客户端发送指定的页面文件
     *
     * @param file 文件
     */
    private void sendHTML(File file) {
        try {
            // 将html文件内容逐行写入html
            if (file.exists()) {
                bufferedReader = new BufferedReader(new FileReader(file.getPath()));
                String str = bufferedReader.readLine();
                while (str != null) {
                    html.append(str).append("\n");
                    str = bufferedReader.readLine();
                }
                // 响应头
                response.append("HTTP/1.0 200 OK" + CRLF);
                response.append("Date: ").append(new Date()).append(CRLF);
                response.append("Content-Type: text/html;charset=ISO-8859-1" + CRLF);
                response.append("Content-Length: ").append(file.length()).append(CRLF);
                response.append(CRLF);
                // 响应体
                response.append(html);

                // 发送响应
                String message = response.toString();
                buffer = message.getBytes();
                outputStream.write(buffer, 0, message.length());
                outputStream.flush();
                outputStream.close();
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 向客户端发送指定的图像文件
     *
     * @param file 文件
     */
    private void sendIMG(File file) {
        try {
            // 响应头
            response.append("HTTP/1.0 200 OK" + CRLF);
            response.append("Date: " + new Date() + CRLF);
            response.append("Content-Type: image/jpeg;charset=ISO-8859-1" + CRLF);
            response.append("Content-Length: " + file.length() + CRLF);
            response.append(CRLF);

            // 发送响应头
            String message = response.toString();
            buffer = message.getBytes(StandardCharsets.ISO_8859_1);
            outputStream.write(buffer, 0, message.length());

            // 发送jpg文件
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
            int length = 0;
            byte[] sendInfo = new byte[8192];
            while ((length = bis.read(sendInfo)) != -1) {
                System.out.println(length);
                outputStream.write(sendInfo, 0, length);
                outputStream.flush();
            }
            outputStream.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
