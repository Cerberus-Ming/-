@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.service.com")
package com.service;