import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;

/**
 * @description: 实现客户端HTTP请求的发送、响应的处理
 * @author Eternity
 * @date 2023/11/2 16:14
 * @version 1.0
 */

public class HttpClient {

    /**
     * Default port is 80.
     */
    //用网址测试GET时，端口号修改为80。 本地时端口号为2023（80端口被占用）
    private static final int PORT = 2023;
    /**
     * default HTTP port is port 80
     */
    private static int port = 80;
    /**
     * Allow a maximum buffer size of 8192 bytes
     */
    private static int buffer_size = 8192;
    /**
     * String to represent the Carriage Return and Line Feed character sequence.
     */
    static private String CRLF = "\r\n";
    /**
     * My socket to the world.
     */
    Socket socket = null;
    /**
     * Output stream to the socket.
     */
    BufferedOutputStream ostream = null;

    /**
     * Input stream from the socket.
     */
    BufferedInputStream istream = null;
    /**
     * Response is stored in a byte array.
     */
    private byte[] buffer;
    /**
     * StringBuffer storing the header
     */
    private StringBuffer header = null;
    /**
     * StringBuffer storing the response.
     */
    private StringBuffer response = null;

    /**
     * HttpClient constructor;
     */
    public HttpClient() {
        buffer = new byte[buffer_size];
        header = new StringBuffer();
        response = new StringBuffer();
    }

    /**
     * <em>connect</em> connects to the input host on the default http port --
     * port 80. This function opens the socket and creates the input and output
     * streams used for communication.
     */
    public void connect(String host) throws Exception {

        /**
         * Open my socket to the specified host at the default port.
         */
        socket = new Socket(host, PORT);

        /**
         * Create the output stream.
         */
        ostream = new BufferedOutputStream(socket.getOutputStream());

        /**
         * Create the input stream.
         */
        istream = new BufferedInputStream(socket.getInputStream());
    }

    /**
     * <em>processGetRequest</em> process the input GET request.
     */
    public void processGetRequest(String request) throws Exception {
        /**
         * Send the request to the server.
         */
        request += CRLF + CRLF;
        buffer = request.getBytes();
        ostream.write(buffer, 0, request.length());
        ostream.flush();
        /**
         * waiting for the response.
         */
        processResponse();
    }

    /**
     * <em>processPutRequest</em> process the input PUT request.
     */
    public void processPutRequest(String request) throws Exception {

        File file = new File("face.jpg");

        // 获取文件类型
        String contentType;
        if (file.getPath().endsWith(".jpg")) {
            contentType = "image/jpg";
        } else if (file.getPath().endsWith(".html")) {
            contentType = "text/html";
        } else {
            contentType = "others";
        }

        // 补充请求头其它信息
        request += CRLF;
        request += "Content-Length: " + file.length() + CRLF;
        request += "Content-type: " + contentType;
        request += CRLF + CRLF; // 请求头结束

        // 发送请求头
        buffer = request.getBytes();
        ostream.write(buffer, 0, request.length());

        // 发送文件
        FileInputStream fistream = new FileInputStream(file);
        buffer = new byte[buffer_size];
        while (fistream.read(buffer) != -1) {
            ostream.write(buffer);
        }
        fistream.close();
        ostream.flush();

        processResponse();
    }

    /**
     * <em>processResponse</em> process the server response.
     */
    public void processResponse() throws Exception {
        int last = 0, c = 0;
        /**
         * Process the header and add it to the header StringBuffer.
         */
        // 提取响应头
        boolean inHeader = true; // loop control
        while (inHeader && ((c = istream.read()) != -1)) {
            switch (c) {
                // '\r'直接跳过
                case '\r':
                    break;
                case '\n':
                    // 响应头以'\r\n'结束，由于已经跳过了'\r'，遇到两个重复的'\n'时，说明响应头结束
                    if (c == last) {
                        inHeader = false;
                        break;
                    }
                    last = c;
                    header.append("\n");
                    break;
                default:
                    last = c;
                    header.append((char) c);
            }
        }

        /**
         * Read the contents and add it to the response StringBuffer.
         */
        // 提取响应文件
        while (istream.read(buffer) != -1) {
            response.append(new String(buffer, "iso-8859-1"));
        }
    }

    /**
     * Get the response header.
     */
    public String getHeader() {
        return header.toString();
    }

    /**
     * Get the server's response.
     */
    public String getResponse() {
        return response.toString();
    }

    /**
     * Close all open connections -- sockets and streams.
     */
    public void close() throws Exception {
        socket.close();
        istream.close();
        ostream.close();
    }
}
