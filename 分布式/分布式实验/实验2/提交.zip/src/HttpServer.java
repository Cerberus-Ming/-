import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @description: 服务器端，实现服务器端的启动，并实时监听客户端的请求，支持多用户并发访问
 * @author Eternity
 * @date 2023/11/2 16:24
 * @version 1.0
 */
public class HttpServer {

    public String rootPath;
    public ServerSocket serverSocket;
    public ExecutorService executorService;
    int PORT = 2023; // 端口号为2023，本地运行时80端口被占用


    /**
     * 构造方法：启动服务器，建立线程池
     *
     * @param rootPath 服务器运行目录：D:\桌面\my分布式实验\exec2\index
     */
    public HttpServer(String rootPath) {
        this.rootPath = rootPath;
        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("服务器启动");
            executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 4);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        // 获取并验证根目录参数
        if (args.length != 1) {
            System.out.println("请传递root目录参数");
        } else {
            File root = new File(args[0]);
            if (root.isDirectory()) {
                HttpServer httpServer = new HttpServer(args[0]);
                httpServer.linkStart();
            } else {
                System.out.println("目录无效");
            }
        }
    }

    /**
     *  每接收到一个客户端请求 就启动一个线程
     */
    public void linkStart() {
        while (true) {
            try {
                Socket socket = serverSocket.accept();
                System.out.println("客户端" + socket.getRemoteSocketAddress() + "连接成功");
                executorService.execute(new Handler(socket, rootPath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
