package bean;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * @description: 用户类
 * @author Eternity
 * @date 2023/11/17 15:15
 * @version 1.0
 */
public class User implements Serializable {

    private String name;
    private String password;
    private ArrayList<Meeting> meetings = new ArrayList<>();

    public User(String name, String password) {
        super();
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return this.name;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<Meeting> getMeetings() {
        return this.meetings;
    }

    public void addMeeting(Meeting meeting) {
        this.meetings.add(meeting);
    }
}
