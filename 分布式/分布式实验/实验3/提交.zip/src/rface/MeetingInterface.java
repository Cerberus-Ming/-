package rface;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * @description: 远程接口
 * @author Eternity
 * @date 2023/11/17 15:19
 * @version 1.0
 */
public interface MeetingInterface extends Remote {

    boolean register(String name, String password) throws RemoteException;

    String addMeeting(String name, String password, String[] participants, String start, String end, String title) throws RemoteException;

    String queryMeeting(String name, String password, String start, String end) throws RemoteException;

    String deleteMeeting(String name, String password, int id) throws RemoteException;

    String clearMeeting(String name, String password) throws RemoteException;
}