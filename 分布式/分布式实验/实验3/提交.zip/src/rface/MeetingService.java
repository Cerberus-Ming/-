package rface;

import bean.Meeting;
import bean.User;

import java.io.Serial;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


/**
 * @description: TODO
 * @author Eternity
 * @date 2023/11/17 15:17
 * @version 1.0
 */
public class MeetingService extends UnicastRemoteObject implements MeetingInterface {

    @Serial
    private static final long serialVersionUID = 1L;
    private static int meetingID = 0;
    private final ArrayList<User> users = new ArrayList<>();
    private final ArrayList<Meeting> meetings = new ArrayList<>();
    private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd,HH:mm");


    public MeetingService() throws RemoteException {
    }

    /**
     * 用户注册
     *
     * @param name     用户名
     * @param password 密码
     * @return 创建结果
     */
    @Override
    public boolean register(String name, String password) throws RemoteException {
        for (User user : users) {
            if (user.getName().equals(name)) {
                System.out.println("Registration failed: The user name [" + user.getName() + "] has already been registered");
                return false;
            }
        }
        User user = new User(name, password);
        users.add(user);
        System.out.println("Register successfully: " + user.getName());
        return true;
    }

    /**
     * 创建会议
     *
     * @param name             会议创建者的用户名
     * @param password         会议创建者的用户密码
     * @param participantNames 字符串数组，每一元素为参会者的用户名
     * @param start            开始时间
     * @param end              结束时间
     * @param title            会议标题
     * @return 结果信息（登录失败信息/创建的会议信息）
     */
    @Override
    public String addMeeting(String name, String password, String[] participantNames, String start, String end, String title) throws RemoteException {
        switch (checkUser(name, password)) {
            case 0 -> {
                return "Username does not exist";
            }
            case 2 -> {
                return "Incorrect username or password";
            }
            case 1 -> {
                Date startDate, endDate;
                try {
                    startDate = dateFormat.parse(start);
                    endDate = dateFormat.parse(end);
                } catch (ParseException e) {
                    return "Wrong format of time: The correct format is [yyyy-MM-dd,HH:mm].";
                }
                if (startDate.after(endDate)) {
                    return "Invalid time: The end time should be later than the start time.";
                }
                if (isTimeConflict(startDate, endDate, name)) {
                    return "Invalid time: This time slot conflicts with a meeting of another presence.";
                }
                if (!checkUser(participantNames)) {
                    return "Invalid participant's username: A non-existent username was entered.";
                }
                if (participantNames.length < 1) {
                    return "At least one participant is required in addition to the initiator.";
                }
                for (String participantName : participantNames) {
                    if (participantName.equals(name)) {
                        return "The username in the other user should not be the initiator itself.";
                    }
                }

                ArrayList<User> participants = new ArrayList<>();
                User initiator = new User(name, password);
                for (String participantName : participantNames) {
                    for (User user : users) {
                        if (user.getName().equals(participantName)) {
                            participants.add(user);
                        }
                    }
                }
                Meeting meeting = new Meeting(meetingID++, title, startDate, endDate, initiator, participants);
                for (User user : users) {
                    if (user.getName().equals(name)) {
                        user.addMeeting(meeting);
                    }
                    for (String participantName : participantNames) {
                        if (user.getName().equals(participantName)) {
                            user.addMeeting(meeting);
                        }
                    }
                }
                meetings.add(meeting);
                String info = "Successfully added meeting, meeting ID: " + meeting.getId();
                System.out.println(info);
                return info;
            }
        }
        return null;
    }

    /**
     * 查询指定时间内的所有会议，返回其信息
     *
     * @param name     用户名
     * @param password 密码
     * @param start    开始时间
     * @param end      截止时间
     * @return 结果信息（登录失败信息/指定的会议信息）
     */
    @Override
    public String queryMeeting(String name, String password, String start, String end) throws RemoteException {
        switch (checkUser(name, password)) {
            case 0 -> {
                return "Username does not exist";
            }
            case 2 -> {
                return "Incorrect username or password";
            }
            case 1 -> {
                Date startDate, endDate;
                try {
                    startDate = dateFormat.parse(start);
                    endDate = dateFormat.parse(end);
                } catch (ParseException e) {
                    return "Wrong format of time: The correct format is [yyyy-MM-dd,HH:mm]";
                }
                if (startDate.after(endDate)) {
                    return "Invalid time: The end time should be later than the start time";
                }
                StringBuilder info = new StringBuilder("Meeting list: \n");
                boolean flag = false;
                for (Meeting meeting : meetings) {
                    if ((!meeting.getStart().before(startDate)) && (!meeting.getEnd().after(endDate))) {
                        info.append(meeting);
                        flag = true;
                    }
                }
                if (flag) {
                    return info.toString();
                } else {
                    return "No meetings during the requested time period";
                }
            }
        }
        return null;
    }

    /**
     * 删除某一用户指定ID的 且由他添加的会议
     *
     * @param name     用户名
     * @param password 密码
     * @param id       会议号
     * @return 结果信息（登录失败信息 / 删除结果信息）
     */
    @Override
    public String deleteMeeting(String name, String password, int id) throws RemoteException {
        switch (checkUser(name, password)) {
            case 0 -> {
                return "Username does not exist";
            }
            case 2 -> {
                return "Incorrect username or password";
            }
            case 1 -> {
                for (Meeting meeting : meetings) {
                    if (meeting.getId() == id && meeting.getInitiator().getName().equals(name)) {
                        String info = "Meeting " + meeting.getId() + " has been deleted";
                        meetings.remove(meeting);
                        System.out.println(info);
                        return info;
                    }
                }
                return "Invalid Meeting ID: Not exist";
            }
        }
        return null;
    }

    /**
     * 清除某一用户创建的会议
     *
     * @param name     用户名
     * @param password 密码
     * @return 结果信息（登录失败信息 / 清除会议信息）
     */
    @Override
    public String clearMeeting(String name, String password) throws RemoteException {
        switch (checkUser(name, password)) {
            case 0 -> {
                return "Username does not exist";
            }
            case 2 -> {
                return "Incorrect username or password";
            }
            case 1 -> {
                for (Meeting meeting : meetings) {
                    User user = new User(name, password);
                    if (user.getMeetings() == null) {
                        return "There is no meeting added by this user";
                    }
                    if (meeting.getInitiator().getName().equals(name)) {
                        meetings.remove(meeting);
                        String info = "The meetings added by " + name + " have been cleared";
                        System.out.println(info);
                        return info;
                    }
                }
            }
        }
        return "There is no meeting added by this user";
    }

    /**
     * 判断用户是否存在 / 若存在，密码是否正确
     *
     * @param name     用户名
     * @param password 密码
     * @return 返回0表示用户不存在，1表示用户名密码正确，2表示密码错误
     */
    private int checkUser(String name, String password) {
        for (User user : users) {
            if (user.getName().equals(name)) {
                if (user.getPassword().equals(password)) {
                    return 1;
                } else {
                    return 2;
                }
            }
        }
        return 0;
    }

    /**
     * 判断用户是否存在
     *
     * @param name 用户名
     */
    private boolean checkUser(String name) {
        for (User user : users) {
            if (user.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断用户是否存在
     *
     * @param names 用户名动态数组
     */
    private boolean checkUser(String[] names) {
        for (String name : names) {
            if (!checkUser(name)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断时间是否冲突
     * 判断时间段是否与用户已加入的会议的时间冲突
     *
     * @param startDate 开始时间
     * @param endDate   截止时间
     * @param name      用户名
     */
    private boolean isTimeConflict(Date startDate, Date endDate, String name) {
        for (User user : users) {
            if (user.getName().equals(name)) {
                ArrayList<Meeting> userMeetings = user.getMeetings();
                for (Meeting meeting : userMeetings) {
                    if ((!startDate.before(meeting.getStart()) && !startDate.after(meeting.getEnd())) ||
                            (!endDate.before(meeting.getStart()) && !endDate.after(meeting.getEnd()))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

