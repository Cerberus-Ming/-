package client;

import rface.MeetingInterface;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.Naming;
import java.util.Arrays;

/**
 * @description: 客户端程序  通过 RMI 与远程会议服务交互
 * @author Eternity
 * @date 2023/11/17 15:09
 * @version 1.0
 */
public class RMIClient {

    private static final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    private static MeetingInterface RMI;
    private static String name = null;
    private static String password = null;
    private static boolean firstTime = true;


    /**
     * 主函数
     *
     * @param args 程序实参，需输入指令
     */
    public static void main(String[] args) {
        if (args.length < 3) { //参数至少包括服务器地址，服务器端口，命令三部分
            wrongCommand();
        }
        try {
            RMI = (MeetingInterface)Naming.lookup("//" + args[0] + ":" + args[1] + "/RMIMeeting");
            run(Arrays.copyOfRange(args, 2, args.length));
        } catch (Exception e) {
            System.out.println("An error occurred while connecting to the server");
            e.printStackTrace();
        }
    }


    /**
     * 程序运行参数错误时的提示
     */
    private static void wrongCommand() {
        String info = """
                  Wrong command!
                  The correct command should be:
                  \tregister: java [clientname] [servername] [portnumber] register [username] [password]
                  \tadd: java [clientname] [servername] [portnumber] add [username] [password] [otherusername] [start] [end] [title]
                  \tquery: java [clientname] [servername] [portnumber] query [username] [password] [start] [end]
                  \tdelete: java [clientname] [servername] [portnumber] delete [username] [password] [meetingid]
                  \tclear: java [clientname] [servername] [portnumber] clear [username] [password]
                """;
        System.out.println(info);
        System.exit(0);
    }


    /**
     * 客户端对不同指令的处理操作
     *
     * @param parameter 指令
     */
    private static void run(String[] parameter) throws IOException {
        switch (parameter[0]) {
            case "register" -> register(parameter);
            case "add" -> add(parameter);
            case "query" -> query(parameter);
            case "delete" -> delete(parameter);
            case "clear" -> clear(parameter);
            case "help" -> help();
            case "quit" -> {
                if (!firstTime) {
                    System.exit(0);
                } else {
                    wrongCommand();
                }
            }
            default -> {
                if (!firstTime) {
                    System.out.println("Invalid command");
                    showMenu();
                    System.out.println("Input an operation: ");
                    String[] command = br.readLine().split(" ");
                    run(command);
                } else {
                    wrongCommand();
                }
            }
        }
    }


    /**
     * 客户端对注册命令的具体处理
     *
     * @param parameter 指令
     */
    private static void register(String[] parameter) throws IOException {
        if (firstTime) {
            if (parameter.length != 3) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tregister: java [clientname] [servername] [portnumber] register [username] [password]
                        """;
                System.out.println(info);
                System.exit(0);
            }
            boolean registerResult = RMI.register(parameter[1], parameter[2]);
            if (registerResult) {
                name = parameter[1];
                password = parameter[2];
                firstTime = false;
                System.out.println("Register successfully!");
            } else {
                System.out.println("The user name has already been registered.");
                System.exit(0);
            }
            showMenu();
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        }
    }


    /**
     * 客户端对添加会议命令具体处理
     *
     * @param parameter 指令
     */
    private static void add(String[] parameter) throws IOException {
        int len = parameter.length;
        if (firstTime) {
            if (len < 7) {
                String info = """
                         Wrong command!
                         The correct command should be:
                         \tjava [clientname] [servername] [portnumber] add [username] [password] [otherusername] [start] [end] [title]
                        """;
                System.out.println(info);
                System.exit(0);
            }
            String[] participants = Arrays.copyOfRange(parameter, 3, len - 3);
            String result = RMI.addMeeting(parameter[1], parameter[2], participants, parameter[len - 3], parameter[len - 2], parameter[len - 1]);
            System.out.println(result);
            if (result.startsWith("Success")) {
                name = parameter[1];
                password = parameter[2];
                firstTime = false;
                System.out.println("Input an operation: ");
                String[] command = br.readLine().split(" ");
                run(command);
            } else {
                System.exit(0);
            }
        } else {
            if (len < 5) {
                String info = """
                         Wrong command!
                         The correct command should be:
                         \tadd [otherusername] [start] [end] [title]
                        """;
                System.out.println(info);
            } else {
                String[] participants = Arrays.copyOfRange(parameter, 1, len - 3);
                System.out.println(RMI.addMeeting(name, password, participants, parameter[len - 3], parameter[len - 2], parameter[len - 1]));
            }
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        }
    }


    /**
     * 客户端对删除会议命令的具体处理
     *
     * @param parameter 指令
     */
    private static void delete(String[] parameter) throws IOException {
        int len = parameter.length;
        if (firstTime) {
            if (len != 4) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tjava [clientname] [servername] [portnumber] delete [username] [password] [meetingid]
                        """;
                System.out.println(info);
                System.exit(0);
            } else {
                String result = RMI.deleteMeeting(parameter[1], parameter[2], Integer.parseInt(parameter[3]));
                System.out.println(result);
                if (result.startsWith("Meeting")) {
                    name = parameter[1];
                    password = parameter[2];
                    firstTime = false;
                    System.out.println("Input an operation: ");
                    String[] command = br.readLine().split(" ");
                    run(command);
                } else {
                    System.exit(0);
                }
            }
        } else {
            if (len != 2) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tdelete [meetingid]
                        """;
                System.out.println(info);
            } else {
                String result = RMI.deleteMeeting(name, password, Integer.parseInt(parameter[1]));
                System.out.println(result);
            }
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        }
    }


    /**
     * 客户端对清除会议命令的具体处理
     *
     * @param parameter 指令
     */
    private static void clear(String[] parameter) throws IOException {
        int len = parameter.length;
        if (firstTime) {
            if (len != 3) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tjava [clientname] [servername] [portnumber] clear [username] [password]
                        """;
                System.out.println(info);
                System.exit(0);
            } else {
                String result = RMI.clearMeeting(parameter[1], parameter[2]);
                if (result != null) {
                    if (result.endsWith("cleared")) {
                        name = parameter[1];
                        password = parameter[2];
                        firstTime = false;
                        System.out.println(result);
                        System.out.println("Input an operation: ");
                        String[] command = br.readLine().split(" ");
                        run(command);
                    } else {
                        System.out.println(result);
                    }
                } else {
                    System.out.println("Input an operation: ");
                    String[] command = br.readLine().split(" ");
                    run(command);
                }
            }
        } else {
            if (len != 1) {
                String info = """
                          Wrong command!
                          The correct command should be:clear
                        """;
                System.out.println(info);
            } else {
                String result = RMI.clearMeeting(name, password);
                System.out.println(result);
            }
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        }
    }


    /**
     * 客户端对查询会议命令的具体处理
     *
     * @param parameter 指令
     */
    private static void query(String[] parameter) throws IOException {
        int len = parameter.length;
        if (firstTime) {
            if (len != 5) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tjava [clientname] [servername] [portnumber] query [username] [password] [start] [end]
                        """;
                System.out.println(info);
                System.exit(0);
            } else {
                String result = RMI.queryMeeting(parameter[1], parameter[2], parameter[3], parameter[4]);
                System.out.println(result);
                if (result.startsWith("Meeting list:")) {
                    name = parameter[1];
                    password = parameter[2];
                    firstTime = false;
                    System.out.println("Input an operation: ");
                    String[] command = br.readLine().split(" ");
                    run(command);
                } else {
                    System.exit(0);
                }
            }
        } else {
            if (len != 3) {
                String info = """
                          Wrong command!
                          The correct command should be:
                          \tquery [start] [end]
                        """;
                System.out.println(info);
                System.exit(0);
            } else {
                String result = RMI.queryMeeting(name, password, parameter[1], parameter[2]);
                System.out.println(result);
            }
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        }
    }


    /**
     * 帮助页面
     */
    private static void help() throws IOException {
        if (!firstTime) {
            showMenu();
            System.out.println("Input an operation: ");
            String[] command = br.readLine().split(" ");
            run(command);
        } else {
            wrongCommand();
        }
    }


    /**
     * 功能菜单
     */
    private static void showMenu() {
        String info = """
                  RMI Menu:
                  \t1. add
                  \t\targuments: <username> <start> <end> <title>
                  \t2. delete
                  \t\targuments: <meetingid>
                  \t3. clear
                  \t\targuments: no args
                  \t4. query
                  \t\targuments: <start> <end>
                  \t5. help
                  \t\targuments: no args
                  \t6. quit
                  \t\targuments: no args
                """;
        System.out.println(info);
    }

}
