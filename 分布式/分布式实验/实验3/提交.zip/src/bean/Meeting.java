package bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 * @description: 会议类
 * @author Eternity
 * @date 2023/11/17 15:13
 * @version 1.0
 */
public class Meeting implements Serializable {

    private int id; // 会议ID
    private String title;   // 会议名臣
    private Date start; // 开始时间
    private Date end;   // 结束时间
    private User initiator; //会议发起人
    private ArrayList<User> participants; //参会者


    public Meeting(int id, String title, Date start, Date end, User initiator, ArrayList<User> participants) {
        this.id = id;
        this.title = title;
        this.start = start;
        this.end = end;
        this.initiator = initiator;
        this.participants = participants;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public User getInitiator() {
        return initiator;
    }

    public void setInitiator(User initiator) {
        this.initiator = initiator;
    }

    public ArrayList<User> getParticipants() {
        return participants;
    }

    public void setParticipants(ArrayList<User> participants) {
        this.participants = participants;
    }

    public String getParticipantNames() {
        StringBuilder nameInfo = new StringBuilder();
        for (int i = 0; i < participants.size() - 1; i++) {
            nameInfo.append(participants.get(i).getName() + ", ");
        }
        nameInfo.append(participants.get(participants.size() - 1).getName());
        return nameInfo.toString();
    }

    @Override
    public String toString() {
        return "[ meeting ID: " + id + ", title: " + title + " ]\n[ start time: " + start + " ]\n[ end time: " + end +
                " ]\n[ initiator: " + initiator.getName() + ", other participants: " + getParticipantNames() + " ]\n";
    }
}

