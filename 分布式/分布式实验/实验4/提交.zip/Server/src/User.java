import java.util.ArrayList;

/**
 * User 用户类
 *
 * @description: 用于表示系统中的用户，包含用户名、密码和待办事项列表等信息。
 * @author Eternity
 * @date 2023/12/2 11:07
 * @version 1.0
 */
public class User {

    private String username;// 用户名
    private String password;// 密码
    private ArrayList<TodoList> itemList = new ArrayList<>();

    /**
     * 构造函数
     */
    public User() {}

    /**
     * 构造函数
     *
     * @param username 用户名
     * @param password 密码
     */
    public User(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }

    /**
     * 获取用户名
     *
     * @return 用户名
     */
    public String getUsername() {
        return username;
    }

    /**
     * 设置用户名
     *
     * @param username 用户名
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 获取密码
     *
     * @return 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 获取待办事项列表
     *
     * @return list 待办事项列表
     */
    public ArrayList<TodoList> getItemList() {
        return itemList;
    }

    /**
     * 添加待办事项
     *
     * @param newTodoList 新的待办事项
     */
    public void addTodoList(TodoList newTodoList) {
        this.itemList.add(newTodoList);
    }

    /**
     * 删除待办事项
     *
     * @param removeTodoList 要删除的待办事项
     */
    public void removeTodoList(TodoList removeTodoList) {
        this.itemList.remove(removeTodoList);
    }

    /**
     * 清除所有待办事项
     */
    public void clearTodoList() {
        this.itemList.clear();
    }

    /**
     * 修改待办事项列表
     *
     * @param newTodoLists 新的待办事项列表
     */
    public void setItemList(ArrayList<TodoList> newTodoLists) {
        this.itemList = newTodoLists;
    }

    @Override
    public String toString() {
        return "[username: " + username + ", password: " + password + "]";
    }

}
