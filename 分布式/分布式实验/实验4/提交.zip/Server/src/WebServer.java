import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.Endpoint;
import java.util.ArrayList;
import java.util.Date;

/**
 * WebServer Web服务器类
 *
 * @description: 一个简单的 Web 服务器，提供用户注册、待办事项管理等功能的 Web 服务
 * @author Eternity
 * @date 2023/12/2 10:31
 * @version 1.0
 */
@WebService(name = "WebService", portName = "Port", targetNamespace = "http://www.service.com")
public class WebServer {

    private ArrayList<User> userList = new ArrayList<>(); // 用户列表
    private ArrayList<TodoList> itemList = new ArrayList<>(); // 待办事项列表
    private int id = 0; // 待办事项ID

    /**
     * 主方法，用于发布 Web 服务端点并启动 Web 服务器
     *
     * @param args 命令行参数
     */
    public static void main(String[] args) {
        // 发布 Web 服务端点
        Endpoint.publish("http://127.0.0.1:8001/webservice/todoList", new WebServer());
        System.out.println("WebService Server start!");
        // 生成本地代码: wsimport -encoding utf-8 -keep http://127.0.0.1:8001/webservice/todoList?wsdl
    }

    /**
     * 用户注册
     *
     * @param user 用户对象
     * @return 注册结果
     */
    @WebMethod
    public boolean register(User user) {
        // 检查是否已存在相同用户名的用户
        if (userList != null) {
            for (User i : userList) {
                if (i.getUsername().equals(user.getUsername())) {
                    return false;
                }
            }
        }
        userList.add(user);
        return true;
    }

    /**
     * 添加待办事项
     *
     * @param username 用户名
     * @param todoList 待加入的事项
     * @return 添加结果
     */
    @WebMethod
    public TodoList add(String username, TodoList todoList) {
        // 获取用户对象
        User user = getUser(username);
        if (user == null) {
            return null;
        }
        // 检查待办事项时间是否冲突
        ArrayList<TodoList> list = user.getItemList();
        if (!list.isEmpty()) {
            for (TodoList temp : list) {
                if (!temp.getStartTime().after(todoList.getStartTime()) && !todoList.getStartTime().after(temp.getEndTime())) {
                    return null;
                }
                if (!temp.getStartTime().after(todoList.getEndTime()) && !todoList.getEndTime().after(temp.getEndTime())) {
                    return null;
                }
                if (!todoList.getStartTime().after(temp.getStartTime()) && !temp.getStartTime().after(todoList.getEndTime())) {
                    return null;
                }
                if (!todoList.getStartTime().after(temp.getEndTime()) && !temp.getEndTime().after(todoList.getEndTime())) {
                    return null;
                }
            }
        }
        todoList.setID(id++);//设置ID
        itemList.add(todoList);
        user.addTodoList(todoList);
        return todoList;
    }

    /**
     * 查询待办事项
     *
     * @param username 用户名
     * @param start 开始时间
     * @param end 结束时间
     * @return 符合条件的待办事项列表
     */
    @WebMethod
    public ArrayList<TodoList> query(String username, Date start, Date end) {
        // 获取用户对象
        User user = getUser(username);
        if (user == null) {
            return null;
        }
        if (itemList.isEmpty()) {
            return null;
        }
        ArrayList<TodoList> userList = user.getItemList(); // 用户的待办事项列表
        ArrayList<TodoList> queryList = new ArrayList<>(); // 符合要求的待办事项列表
        if (userList != null) {
            for (TodoList todoList : userList) {
                if (!start.after(todoList.getStartTime()) && !end.before(todoList.getEndTime())) {
                    queryList.add(todoList);
                }
            }
            return queryList;
        } else {
            return null;
        }
    }

    /**
     * 删除项目
     *
     * @param username 用户名
     * @param id 待删除的项目ID
     * @return 删除结果
     */
    @WebMethod
    public boolean delete(String username, int id) {
        // 获取用户对象
        User user = getUser(username);
        if (user == null) {
            return false;
        }
        // 查找待删除的待办事项
        TodoList itemToDelete = null;
        for (TodoList todoList : user.getItemList()) {
            if (todoList.getID() == id) {
                itemToDelete = todoList;
                break;
            }
        }
        if (itemToDelete == null) {
            return false;
        } else {
            itemList.remove(itemToDelete);
            user.removeTodoList(itemToDelete);
            return true;
        }
    }

    /**
     * 清空代办事项列表
     *
     * @param username 用户名
     * @return 清空结果
     */
    @WebMethod
    public boolean clear(String username) {
        // 获取用户对象
        User user = getUser(username);
        if (user == null) {
            return false;
        }
        // 待删除的待办事项列表
        ArrayList<TodoList> listToClear = user.getItemList();
        if (!listToClear.isEmpty()) {
            for (TodoList todoList : listToClear) {
                itemList.remove(todoList);
            }
            user.clearTodoList();
        }
        return true;
    }

    /**
     * 获得用户
     *
     * @param username 用户名
     * @return 用户
     */
    private User getUser(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }
}
